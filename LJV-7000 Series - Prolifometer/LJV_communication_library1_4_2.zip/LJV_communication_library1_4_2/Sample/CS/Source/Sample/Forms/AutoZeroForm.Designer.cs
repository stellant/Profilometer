﻿namespace LJV7_IF_Test.Forms
{
    partial class AutoZeroForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._chkboxBit1 = new System.Windows.Forms.CheckBox();
            this._chkboxBit2 = new System.Windows.Forms.CheckBox();
            this._chkboxBit3 = new System.Windows.Forms.CheckBox();
            this._chkboxBit4 = new System.Windows.Forms.CheckBox();
            this._chkboxBit5 = new System.Windows.Forms.CheckBox();
            this._chkboxBit6 = new System.Windows.Forms.CheckBox();
            this._chkboxBit7 = new System.Windows.Forms.CheckBox();
            this._chkboxBit8 = new System.Windows.Forms.CheckBox();
            this._chkboxBit9 = new System.Windows.Forms.CheckBox();
            this._chkboxBit10 = new System.Windows.Forms.CheckBox();
            this._chkboxBit11 = new System.Windows.Forms.CheckBox();
            this._chkboxBit12 = new System.Windows.Forms.CheckBox();
            this._chkboxBit13 = new System.Windows.Forms.CheckBox();
            this._chkboxBit14 = new System.Windows.Forms.CheckBox();
            this._chkboxBit15 = new System.Windows.Forms.CheckBox();
            this._chkboxBit16 = new System.Windows.Forms.CheckBox();
            this._btnCancel = new System.Windows.Forms.Button();
            this._btnOk = new System.Windows.Forms.Button();
            this._lblOnOff = new System.Windows.Forms.Label();
            this._txtboxOnOff = new System.Windows.Forms.TextBox();
            this._lblOnOffDescription = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // _chkboxBit1
            // 
            this._chkboxBit1.AutoSize = true;
            this._chkboxBit1.Location = new System.Drawing.Point(21, 70);
            this._chkboxBit1.Name = "_chkboxBit1";
            this._chkboxBit1.Size = new System.Drawing.Size(30, 16);
            this._chkboxBit1.TabIndex = 1;
            this._chkboxBit1.Text = "1";
            this._chkboxBit1.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit2
            // 
            this._chkboxBit2.AutoSize = true;
            this._chkboxBit2.Location = new System.Drawing.Point(70, 70);
            this._chkboxBit2.Name = "_chkboxBit2";
            this._chkboxBit2.Size = new System.Drawing.Size(30, 16);
            this._chkboxBit2.TabIndex = 2;
            this._chkboxBit2.Text = "2";
            this._chkboxBit2.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit3
            // 
            this._chkboxBit3.AutoSize = true;
            this._chkboxBit3.Location = new System.Drawing.Point(119, 70);
            this._chkboxBit3.Name = "_chkboxBit3";
            this._chkboxBit3.Size = new System.Drawing.Size(30, 16);
            this._chkboxBit3.TabIndex = 3;
            this._chkboxBit3.Text = "3";
            this._chkboxBit3.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit4
            // 
            this._chkboxBit4.AutoSize = true;
            this._chkboxBit4.Location = new System.Drawing.Point(168, 70);
            this._chkboxBit4.Name = "_chkboxBit4";
            this._chkboxBit4.Size = new System.Drawing.Size(30, 16);
            this._chkboxBit4.TabIndex = 4;
            this._chkboxBit4.Text = "4";
            this._chkboxBit4.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit5
            // 
            this._chkboxBit5.AutoSize = true;
            this._chkboxBit5.Location = new System.Drawing.Point(21, 97);
            this._chkboxBit5.Name = "_chkboxBit5";
            this._chkboxBit5.Size = new System.Drawing.Size(30, 16);
            this._chkboxBit5.TabIndex = 5;
            this._chkboxBit5.Text = "5";
            this._chkboxBit5.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit6
            // 
            this._chkboxBit6.AutoSize = true;
            this._chkboxBit6.Location = new System.Drawing.Point(70, 97);
            this._chkboxBit6.Name = "_chkboxBit6";
            this._chkboxBit6.Size = new System.Drawing.Size(30, 16);
            this._chkboxBit6.TabIndex = 6;
            this._chkboxBit6.Text = "6";
            this._chkboxBit6.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit7
            // 
            this._chkboxBit7.AutoSize = true;
            this._chkboxBit7.Location = new System.Drawing.Point(119, 97);
            this._chkboxBit7.Name = "_chkboxBit7";
            this._chkboxBit7.Size = new System.Drawing.Size(30, 16);
            this._chkboxBit7.TabIndex = 7;
            this._chkboxBit7.Text = "7";
            this._chkboxBit7.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit8
            // 
            this._chkboxBit8.AutoSize = true;
            this._chkboxBit8.Location = new System.Drawing.Point(168, 97);
            this._chkboxBit8.Name = "_chkboxBit8";
            this._chkboxBit8.Size = new System.Drawing.Size(30, 16);
            this._chkboxBit8.TabIndex = 8;
            this._chkboxBit8.Text = "8";
            this._chkboxBit8.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit9
            // 
            this._chkboxBit9.AutoSize = true;
            this._chkboxBit9.Location = new System.Drawing.Point(20, 124);
            this._chkboxBit9.Name = "_chkboxBit9";
            this._chkboxBit9.Size = new System.Drawing.Size(30, 16);
            this._chkboxBit9.TabIndex = 9;
            this._chkboxBit9.Text = "9";
            this._chkboxBit9.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit10
            // 
            this._chkboxBit10.AutoSize = true;
            this._chkboxBit10.Location = new System.Drawing.Point(70, 124);
            this._chkboxBit10.Name = "_chkboxBit10";
            this._chkboxBit10.Size = new System.Drawing.Size(36, 16);
            this._chkboxBit10.TabIndex = 10;
            this._chkboxBit10.Text = "10";
            this._chkboxBit10.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit11
            // 
            this._chkboxBit11.AutoSize = true;
            this._chkboxBit11.Location = new System.Drawing.Point(119, 124);
            this._chkboxBit11.Name = "_chkboxBit11";
            this._chkboxBit11.Size = new System.Drawing.Size(36, 16);
            this._chkboxBit11.TabIndex = 11;
            this._chkboxBit11.Text = "11";
            this._chkboxBit11.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit12
            // 
            this._chkboxBit12.AutoSize = true;
            this._chkboxBit12.Location = new System.Drawing.Point(168, 124);
            this._chkboxBit12.Name = "_chkboxBit12";
            this._chkboxBit12.Size = new System.Drawing.Size(36, 16);
            this._chkboxBit12.TabIndex = 12;
            this._chkboxBit12.Text = "12";
            this._chkboxBit12.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit13
            // 
            this._chkboxBit13.AutoSize = true;
            this._chkboxBit13.Location = new System.Drawing.Point(20, 151);
            this._chkboxBit13.Name = "_chkboxBit13";
            this._chkboxBit13.Size = new System.Drawing.Size(36, 16);
            this._chkboxBit13.TabIndex = 13;
            this._chkboxBit13.Text = "13";
            this._chkboxBit13.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit14
            // 
            this._chkboxBit14.AutoSize = true;
            this._chkboxBit14.Location = new System.Drawing.Point(69, 151);
            this._chkboxBit14.Name = "_chkboxBit14";
            this._chkboxBit14.Size = new System.Drawing.Size(36, 16);
            this._chkboxBit14.TabIndex = 14;
            this._chkboxBit14.Text = "14";
            this._chkboxBit14.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit15
            // 
            this._chkboxBit15.AutoSize = true;
            this._chkboxBit15.Location = new System.Drawing.Point(118, 151);
            this._chkboxBit15.Name = "_chkboxBit15";
            this._chkboxBit15.Size = new System.Drawing.Size(36, 16);
            this._chkboxBit15.TabIndex = 15;
            this._chkboxBit15.Text = "15";
            this._chkboxBit15.UseVisualStyleBackColor = true;
            // 
            // _chkboxBit16
            // 
            this._chkboxBit16.AutoSize = true;
            this._chkboxBit16.Location = new System.Drawing.Point(167, 151);
            this._chkboxBit16.Name = "_chkboxBit16";
            this._chkboxBit16.Size = new System.Drawing.Size(36, 16);
            this._chkboxBit16.TabIndex = 16;
            this._chkboxBit16.Text = "16";
            this._chkboxBit16.UseVisualStyleBackColor = true;
            // 
            // _btnCancel
            // 
            this._btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this._btnCancel.Location = new System.Drawing.Point(118, 186);
            this._btnCancel.Name = "_btnCancel";
            this._btnCancel.Size = new System.Drawing.Size(75, 23);
            this._btnCancel.TabIndex = 18;
            this._btnCancel.Text = "キャンセル";
            this._btnCancel.UseVisualStyleBackColor = true;
            // 
            // _btnOk
            // 
            this._btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this._btnOk.Location = new System.Drawing.Point(17, 186);
            this._btnOk.Name = "_btnOk";
            this._btnOk.Size = new System.Drawing.Size(75, 23);
            this._btnOk.TabIndex = 17;
            this._btnOk.Text = "OK";
            this._btnOk.UseVisualStyleBackColor = true;
            // 
            // _lblOnOff
            // 
            this._lblOnOff.AutoSize = true;
            this._lblOnOff.Location = new System.Drawing.Point(19, 13);
            this._lblOnOff.Name = "_lblOnOff";
            this._lblOnOff.Size = new System.Drawing.Size(119, 12);
            this._lblOnOff.TabIndex = 19;
            this._lblOnOff.Text = "オートゼロON/OFF要求";
            // 
            // _txtboxOnOff
            // 
            this._txtboxOnOff.Location = new System.Drawing.Point(144, 10);
            this._txtboxOnOff.MaxLength = 1;
            this._txtboxOnOff.Name = "_txtboxOnOff";
            this._txtboxOnOff.Size = new System.Drawing.Size(71, 19);
            this._txtboxOnOff.TabIndex = 20;
            this._txtboxOnOff.Text = "0";
            // 
            // _lblOnOffDescription
            // 
            this._lblOnOffDescription.Location = new System.Drawing.Point(17, 32);
            this._lblOnOffDescription.Name = "_lblOnOffDescription";
            this._lblOnOffDescription.Size = new System.Drawing.Size(204, 22);
            this._lblOnOffDescription.TabIndex = 21;
            this._lblOnOffDescription.Text = "０以外：オートゼロＯＮ要求、０：ＯＦＦ要求";
            this._lblOnOffDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // AutoZeroForm
            // 
            this.AcceptButton = this._btnOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this._btnCancel;
            this.ClientSize = new System.Drawing.Size(233, 224);
            this.Controls.Add(this._lblOnOffDescription);
            this.Controls.Add(this._txtboxOnOff);
            this.Controls.Add(this._lblOnOff);
            this.Controls.Add(this._btnCancel);
            this.Controls.Add(this._btnOk);
            this.Controls.Add(this._chkboxBit16);
            this.Controls.Add(this._chkboxBit15);
            this.Controls.Add(this._chkboxBit14);
            this.Controls.Add(this._chkboxBit13);
            this.Controls.Add(this._chkboxBit12);
            this.Controls.Add(this._chkboxBit11);
            this.Controls.Add(this._chkboxBit10);
            this.Controls.Add(this._chkboxBit9);
            this.Controls.Add(this._chkboxBit8);
            this.Controls.Add(this._chkboxBit7);
            this.Controls.Add(this._chkboxBit6);
            this.Controls.Add(this._chkboxBit5);
            this.Controls.Add(this._chkboxBit4);
            this.Controls.Add(this._chkboxBit3);
            this.Controls.Add(this._chkboxBit2);
            this.Controls.Add(this._chkboxBit1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AutoZeroForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ダイアログ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox _chkboxBit1;
        private System.Windows.Forms.CheckBox _chkboxBit2;
        private System.Windows.Forms.CheckBox _chkboxBit3;
        private System.Windows.Forms.CheckBox _chkboxBit4;
        private System.Windows.Forms.CheckBox _chkboxBit5;
        private System.Windows.Forms.CheckBox _chkboxBit6;
        private System.Windows.Forms.CheckBox _chkboxBit7;
        private System.Windows.Forms.CheckBox _chkboxBit8;
        private System.Windows.Forms.CheckBox _chkboxBit9;
        private System.Windows.Forms.CheckBox _chkboxBit10;
        private System.Windows.Forms.CheckBox _chkboxBit11;
        private System.Windows.Forms.CheckBox _chkboxBit12;
        private System.Windows.Forms.CheckBox _chkboxBit13;
        private System.Windows.Forms.CheckBox _chkboxBit14;
        private System.Windows.Forms.CheckBox _chkboxBit15;
        private System.Windows.Forms.CheckBox _chkboxBit16;
        private System.Windows.Forms.Button _btnCancel;
        private System.Windows.Forms.Button _btnOk;
        private System.Windows.Forms.Label _lblOnOff;
        private System.Windows.Forms.TextBox _txtboxOnOff;
        private System.Windows.Forms.Label _lblOnOffDescription;
    }
}