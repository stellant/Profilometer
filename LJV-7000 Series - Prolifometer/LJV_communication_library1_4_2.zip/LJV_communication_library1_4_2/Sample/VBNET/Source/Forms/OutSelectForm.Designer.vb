Namespace Forms
	Partial Class OutSelectForm
		''' <summary>
		''' Required designer variable.
		''' </summary>
		Private components As System.ComponentModel.IContainer = Nothing

		''' <summary>
		''' Clean up any resources being used.
		''' </summary>
		''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		Protected Overrides Sub Dispose(disposing As Boolean)
			If disposing AndAlso (components IsNot Nothing) Then
				components.Dispose()
			End If
			MyBase.Dispose(disposing)
		End Sub

		#Region "Windows Form Designer generated code"

		''' <summary>
		''' Required method for Designer support - do not modify
		''' the contents of this method with the code editor.
		''' </summary>
		Private Sub InitializeComponent()
			Me._chkboxBit1 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit2 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit3 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit4 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit5 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit6 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit7 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit8 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit9 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit10 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit11 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit12 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit13 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit14 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit15 = New System.Windows.Forms.CheckBox()
			Me._chkboxBit16 = New System.Windows.Forms.CheckBox()
			Me._btnCancel = New System.Windows.Forms.Button()
			Me._btnOk = New System.Windows.Forms.Button()
			Me._lblOnOff = New System.Windows.Forms.Label()
			Me._txtboxOnOff = New System.Windows.Forms.TextBox()
			Me._lblOnOffDescription = New System.Windows.Forms.Label()
			Me.groupBox1 = New System.Windows.Forms.GroupBox()
			Me.groupBox1.SuspendLayout()
			Me.SuspendLayout()
			' 
			' _chkboxBit1
			' 
			Me._chkboxBit1.AutoSize = True
			Me._chkboxBit1.Checked = True
			Me._chkboxBit1.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit1.Location = New System.Drawing.Point(18, 20)
			Me._chkboxBit1.Name = "_chkboxBit1"
			Me._chkboxBit1.Size = New System.Drawing.Size(32, 17)
			Me._chkboxBit1.TabIndex = 1
			Me._chkboxBit1.Text = "1"
			Me._chkboxBit1.UseVisualStyleBackColor = True
			' 
			' _chkboxBit2
			' 
			Me._chkboxBit2.AutoSize = True
			Me._chkboxBit2.Checked = True
			Me._chkboxBit2.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit2.Location = New System.Drawing.Point(60, 20)
			Me._chkboxBit2.Name = "_chkboxBit2"
			Me._chkboxBit2.Size = New System.Drawing.Size(32, 17)
			Me._chkboxBit2.TabIndex = 2
			Me._chkboxBit2.Text = "2"
			Me._chkboxBit2.UseVisualStyleBackColor = True
			' 
			' _chkboxBit3
			' 
			Me._chkboxBit3.AutoSize = True
			Me._chkboxBit3.Checked = True
			Me._chkboxBit3.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit3.Location = New System.Drawing.Point(102, 20)
			Me._chkboxBit3.Name = "_chkboxBit3"
			Me._chkboxBit3.Size = New System.Drawing.Size(32, 17)
			Me._chkboxBit3.TabIndex = 3
			Me._chkboxBit3.Text = "3"
			Me._chkboxBit3.UseVisualStyleBackColor = True
			' 
			' _chkboxBit4
			' 
			Me._chkboxBit4.AutoSize = True
			Me._chkboxBit4.Checked = True
			Me._chkboxBit4.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit4.Location = New System.Drawing.Point(144, 20)
			Me._chkboxBit4.Name = "_chkboxBit4"
			Me._chkboxBit4.Size = New System.Drawing.Size(32, 17)
			Me._chkboxBit4.TabIndex = 4
			Me._chkboxBit4.Text = "4"
			Me._chkboxBit4.UseVisualStyleBackColor = True
			' 
			' _chkboxBit5
			' 
			Me._chkboxBit5.AutoSize = True
			Me._chkboxBit5.Checked = True
			Me._chkboxBit5.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit5.Location = New System.Drawing.Point(18, 49)
			Me._chkboxBit5.Name = "_chkboxBit5"
			Me._chkboxBit5.Size = New System.Drawing.Size(32, 17)
			Me._chkboxBit5.TabIndex = 5
			Me._chkboxBit5.Text = "5"
			Me._chkboxBit5.UseVisualStyleBackColor = True
			' 
			' _chkboxBit6
			' 
			Me._chkboxBit6.AutoSize = True
			Me._chkboxBit6.Checked = True
			Me._chkboxBit6.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit6.Location = New System.Drawing.Point(60, 49)
			Me._chkboxBit6.Name = "_chkboxBit6"
			Me._chkboxBit6.Size = New System.Drawing.Size(32, 17)
			Me._chkboxBit6.TabIndex = 6
			Me._chkboxBit6.Text = "6"
			Me._chkboxBit6.UseVisualStyleBackColor = True
			' 
			' _chkboxBit7
			' 
			Me._chkboxBit7.AutoSize = True
			Me._chkboxBit7.Checked = True
			Me._chkboxBit7.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit7.Location = New System.Drawing.Point(102, 49)
			Me._chkboxBit7.Name = "_chkboxBit7"
			Me._chkboxBit7.Size = New System.Drawing.Size(32, 17)
			Me._chkboxBit7.TabIndex = 7
			Me._chkboxBit7.Text = "7"
			Me._chkboxBit7.UseVisualStyleBackColor = True
			' 
			' _chkboxBit8
			' 
			Me._chkboxBit8.AutoSize = True
			Me._chkboxBit8.Checked = True
			Me._chkboxBit8.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit8.Location = New System.Drawing.Point(145, 49)
			Me._chkboxBit8.Name = "_chkboxBit8"
			Me._chkboxBit8.Size = New System.Drawing.Size(32, 17)
			Me._chkboxBit8.TabIndex = 8
			Me._chkboxBit8.Text = "8"
			Me._chkboxBit8.UseVisualStyleBackColor = True
			' 
			' _chkboxBit9
			' 
			Me._chkboxBit9.AutoSize = True
			Me._chkboxBit9.Checked = True
			Me._chkboxBit9.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit9.Location = New System.Drawing.Point(18, 78)
			Me._chkboxBit9.Name = "_chkboxBit9"
			Me._chkboxBit9.Size = New System.Drawing.Size(32, 17)
			Me._chkboxBit9.TabIndex = 9
			Me._chkboxBit9.Text = "9"
			Me._chkboxBit9.UseVisualStyleBackColor = True
			' 
			' _chkboxBit10
			' 
			Me._chkboxBit10.AutoSize = True
			Me._chkboxBit10.Checked = True
			Me._chkboxBit10.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit10.Location = New System.Drawing.Point(60, 78)
			Me._chkboxBit10.Name = "_chkboxBit10"
			Me._chkboxBit10.Size = New System.Drawing.Size(38, 17)
			Me._chkboxBit10.TabIndex = 10
			Me._chkboxBit10.Text = "10"
			Me._chkboxBit10.UseVisualStyleBackColor = True
			' 
			' _chkboxBit11
			' 
			Me._chkboxBit11.AutoSize = True
			Me._chkboxBit11.Checked = True
			Me._chkboxBit11.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit11.Location = New System.Drawing.Point(102, 78)
			Me._chkboxBit11.Name = "_chkboxBit11"
			Me._chkboxBit11.Size = New System.Drawing.Size(38, 17)
			Me._chkboxBit11.TabIndex = 11
			Me._chkboxBit11.Text = "11"
			Me._chkboxBit11.UseVisualStyleBackColor = True
			' 
			' _chkboxBit12
			' 
			Me._chkboxBit12.AutoSize = True
			Me._chkboxBit12.Checked = True
			Me._chkboxBit12.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit12.Location = New System.Drawing.Point(145, 78)
			Me._chkboxBit12.Name = "_chkboxBit12"
			Me._chkboxBit12.Size = New System.Drawing.Size(38, 17)
			Me._chkboxBit12.TabIndex = 12
			Me._chkboxBit12.Text = "12"
			Me._chkboxBit12.UseVisualStyleBackColor = True
			' 
			' _chkboxBit13
			' 
			Me._chkboxBit13.AutoSize = True
			Me._chkboxBit13.Checked = True
			Me._chkboxBit13.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit13.Location = New System.Drawing.Point(18, 107)
			Me._chkboxBit13.Name = "_chkboxBit13"
			Me._chkboxBit13.Size = New System.Drawing.Size(38, 17)
			Me._chkboxBit13.TabIndex = 13
			Me._chkboxBit13.Text = "13"
			Me._chkboxBit13.UseVisualStyleBackColor = True
			' 
			' _chkboxBit14
			' 
			Me._chkboxBit14.AutoSize = True
			Me._chkboxBit14.Checked = True
			Me._chkboxBit14.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit14.Location = New System.Drawing.Point(60, 107)
			Me._chkboxBit14.Name = "_chkboxBit14"
			Me._chkboxBit14.Size = New System.Drawing.Size(38, 17)
			Me._chkboxBit14.TabIndex = 14
			Me._chkboxBit14.Text = "14"
			Me._chkboxBit14.UseVisualStyleBackColor = True
			' 
			' _chkboxBit15
			' 
			Me._chkboxBit15.AutoSize = True
			Me._chkboxBit15.Checked = True
			Me._chkboxBit15.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit15.Location = New System.Drawing.Point(102, 107)
			Me._chkboxBit15.Name = "_chkboxBit15"
			Me._chkboxBit15.Size = New System.Drawing.Size(38, 17)
			Me._chkboxBit15.TabIndex = 15
			Me._chkboxBit15.Text = "15"
			Me._chkboxBit15.UseVisualStyleBackColor = True
			' 
			' _chkboxBit16
			' 
			Me._chkboxBit16.AutoSize = True
			Me._chkboxBit16.Checked = True
			Me._chkboxBit16.CheckState = System.Windows.Forms.CheckState.Checked
			Me._chkboxBit16.Location = New System.Drawing.Point(145, 107)
			Me._chkboxBit16.Name = "_chkboxBit16"
			Me._chkboxBit16.Size = New System.Drawing.Size(38, 17)
			Me._chkboxBit16.TabIndex = 16
			Me._chkboxBit16.Text = "16"
			Me._chkboxBit16.UseVisualStyleBackColor = True
			' 
			' _btnCancel
			' 
			Me._btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
			Me._btnCancel.Location = New System.Drawing.Point(112, 231)
			Me._btnCancel.Name = "_btnCancel"
			Me._btnCancel.Size = New System.Drawing.Size(75, 25)
			Me._btnCancel.TabIndex = 18
			Me._btnCancel.Text = "Cancel"
			Me._btnCancel.UseVisualStyleBackColor = True
			' 
			' _btnOk
			' 
			Me._btnOk.DialogResult = System.Windows.Forms.DialogResult.OK
			Me._btnOk.Location = New System.Drawing.Point(30, 231)
			Me._btnOk.Name = "_btnOk"
			Me._btnOk.Size = New System.Drawing.Size(75, 25)
			Me._btnOk.TabIndex = 17
			Me._btnOk.Text = "OK"
			Me._btnOk.UseVisualStyleBackColor = True
			' 
			' _lblOnOff
			' 
			Me._lblOnOff.AutoSize = True
			Me._lblOnOff.Location = New System.Drawing.Point(17, 14)
			Me._lblOnOff.Name = "_lblOnOff"
			Me._lblOnOff.Size = New System.Drawing.Size(79, 13)
			Me._lblOnOff.TabIndex = 19
			Me._lblOnOff.Text = "On/off request"
			' 
			' _txtboxOnOff
			' 
			Me._txtboxOnOff.Location = New System.Drawing.Point(109, 11)
			Me._txtboxOnOff.MaxLength = 1
			Me._txtboxOnOff.Name = "_txtboxOnOff"
			Me._txtboxOnOff.Size = New System.Drawing.Size(66, 21)
			Me._txtboxOnOff.TabIndex = 20
			Me._txtboxOnOff.Text = "0"
			' 
			' _lblOnOffDescription
			' 
			Me._lblOnOffDescription.AutoSize = True
			Me._lblOnOffDescription.Location = New System.Drawing.Point(17, 35)
			Me._lblOnOffDescription.Name = "_lblOnOffDescription"
			Me._lblOnOffDescription.Size = New System.Drawing.Size(202, 13)
			Me._lblOnOffDescription.TabIndex = 21
			Me._lblOnOffDescription.Text = "Other than 0: on request, 0: off request"
			Me._lblOnOffDescription.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
			' 
			' groupBox1
			' 
			Me.groupBox1.Controls.Add(Me._chkboxBit1)
			Me.groupBox1.Controls.Add(Me._chkboxBit2)
			Me.groupBox1.Controls.Add(Me._chkboxBit3)
			Me.groupBox1.Controls.Add(Me._chkboxBit4)
			Me.groupBox1.Controls.Add(Me._chkboxBit5)
			Me.groupBox1.Controls.Add(Me._chkboxBit6)
			Me.groupBox1.Controls.Add(Me._chkboxBit7)
			Me.groupBox1.Controls.Add(Me._chkboxBit16)
			Me.groupBox1.Controls.Add(Me._chkboxBit8)
			Me.groupBox1.Controls.Add(Me._chkboxBit15)
			Me.groupBox1.Controls.Add(Me._chkboxBit9)
			Me.groupBox1.Controls.Add(Me._chkboxBit14)
			Me.groupBox1.Controls.Add(Me._chkboxBit10)
			Me.groupBox1.Controls.Add(Me._chkboxBit13)
			Me.groupBox1.Controls.Add(Me._chkboxBit11)
			Me.groupBox1.Controls.Add(Me._chkboxBit12)
			Me.groupBox1.Location = New System.Drawing.Point(12, 69)
			Me.groupBox1.Name = "groupBox1"
			Me.groupBox1.Size = New System.Drawing.Size(191, 135)
			Me.groupBox1.TabIndex = 24
			Me.groupBox1.TabStop = False
			Me.groupBox1.Text = "Target OUT (the lower 16 bits)"
			' 
			' OutSelectForm
			' 
			Me.AcceptButton = Me._btnOk
			Me.AutoScaleDimensions = New System.Drawing.SizeF(6F, 13F)
			Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
			Me.CancelButton = Me._btnCancel
			Me.ClientSize = New System.Drawing.Size(240, 269)
			Me.Controls.Add(Me._lblOnOffDescription)
			Me.Controls.Add(Me._txtboxOnOff)
			Me.Controls.Add(Me._lblOnOff)
			Me.Controls.Add(Me._btnCancel)
			Me.Controls.Add(Me._btnOk)
			Me.Controls.Add(Me.groupBox1)
			Me.Font = New System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CByte(0))
			Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
			Me.MaximizeBox = False
			Me.MinimizeBox = False
			Me.Name = "OutSelectForm"
			Me.ShowIcon = False
			Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
			Me.Text = "Dialog box"
			Me.groupBox1.ResumeLayout(False)
			Me.groupBox1.PerformLayout()
			Me.ResumeLayout(False)
			Me.PerformLayout()

		End Sub

		#End Region

		Private _chkboxBit1 As System.Windows.Forms.CheckBox
		Private _chkboxBit2 As System.Windows.Forms.CheckBox
		Private _chkboxBit3 As System.Windows.Forms.CheckBox
		Private _chkboxBit4 As System.Windows.Forms.CheckBox
		Private _chkboxBit5 As System.Windows.Forms.CheckBox
		Private _chkboxBit6 As System.Windows.Forms.CheckBox
		Private _chkboxBit7 As System.Windows.Forms.CheckBox
		Private _chkboxBit8 As System.Windows.Forms.CheckBox
		Private _chkboxBit9 As System.Windows.Forms.CheckBox
		Private _chkboxBit10 As System.Windows.Forms.CheckBox
		Private _chkboxBit11 As System.Windows.Forms.CheckBox
		Private _chkboxBit12 As System.Windows.Forms.CheckBox
		Private _chkboxBit13 As System.Windows.Forms.CheckBox
		Private _chkboxBit14 As System.Windows.Forms.CheckBox
		Private _chkboxBit15 As System.Windows.Forms.CheckBox
		Private _chkboxBit16 As System.Windows.Forms.CheckBox
		Private _btnCancel As System.Windows.Forms.Button
		Private _btnOk As System.Windows.Forms.Button
		Private _lblOnOff As System.Windows.Forms.Label
		Private _txtboxOnOff As System.Windows.Forms.TextBox
		Private _lblOnOffDescription As System.Windows.Forms.Label
		Private groupBox1 As System.Windows.Forms.GroupBox
	End Class
End Namespace
